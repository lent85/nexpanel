-- NexPanel Dump for cli_app_db
-- Engine: Internal MySQL 8.4 (mysql 8.4)
-- Date: 2026-11-19T16:07:43.249Z
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`option_id`)
);
INSERT INTO `wp_options` (`option_name`, `option_value`) VALUES ('siteurl', 'https://cli-app-db.local');
INSERT INTO `wp_options` (`option_name`, `option_value`) VALUES ('home', 'https://cli-app-db.local');
SET FOREIGN_KEY_CHECKS=1;
