-- NexPanel Database Dump for cli_app_db
-- Engine: Internal MySQL 8.4 (mysql 8.4)
-- Timestamp: 2026-11-19T15:14:25.612Z
-- Options: structure=true, data=true

CREATE TABLE IF NOT EXISTS `nexpanel_schema_version` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `version` VARCHAR(32) NOT NULL
);

INSERT INTO `nexpanel_schema_version` (`version`) VALUES ('1.0.0');
